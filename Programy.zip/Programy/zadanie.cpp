#include <iostream>
#include <cmath>

using namespace std;


bool isPrime(int n)
{
    if(n==1)
        return false;
    for(int i=2; i*i<=n; i++)
    {
        if(n%i==0)
        {
            return false;
        }
    }
    return true;
}

int main()
{
    int n;
    cin >> n;

    int amount = sqrt(n);

    int tab[amount];
    for(int i=0; i<=amount; i++)
        tab[i]=0;

    while(n>1)
        for(int i=2; i<=amount; i++)
        {
            if(isPrime(i)==false)
                continue;
            if(n%i==0)
            {
                tab[i-1]++;
                n/=i;
                break;
            }
        }
    for(int i=1; i<amount; i++)
        if(tab[i]!=0)
            cout << i+1 << " - " << tab[i] << endl;
    return 0;
}
