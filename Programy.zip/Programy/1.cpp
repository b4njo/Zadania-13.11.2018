#include <iostream>
#include<cmath>

using namespace std;


bool isPrime(int n)
{
    if(n==1)
        return false;
    for(int i=2; i*i<=n; i++)
    {
        if(n%i==0)
        {
            return false;
        }
    }
    return true;
}

bool isTwins(int a, int b)
{
    if((isPrime(a)==true) && (isPrime(b)==true) && (fabs(a-b)==2))
        return true;
    else
        return false;
}

bool isPerfect(int n)
{
    int sum=0;
    for(int i=1; i<n; i++)
        if(n%i==0)
            sum+=i;
    if(sum==n)
        return true;
    else
        return false;
}
int main()
{
    /*int input1, input2;
    cin >> input1 >> input2;

    if(isTwins(input1, input2)==true)
        cout << "Twin Numbers";
    else
        cout << "Not a Twin Numbers";*/
    int input;
    cin >> input;

    if(isPerfect(input)==true)
        cout << "Perfect Number";
    else
        cout << "Not a Perfect Number";
    return 0;
}
